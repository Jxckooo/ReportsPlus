package me.Jacko.ReportsPlus.Commands;

import java.util.LinkedList;

import org.bukkit.command.Command;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import me.Jacko.ReportsPlus.ReportsPlus;
import me.Jacko.ReportsPlus.Utils.Utils;

public class ReportClear implements BaseCMD {
	
	FileConfiguration config = ReportsPlus.plugin.getCustomConfig();
	
	@Override
	public boolean execute(Player player, Command cmdObj, String label, String cmd, LinkedList<String> args) {
		
		if(player.hasPermission(config.getString("PermissionNode"))) {
			if(cmd.toString().length() > 2) {
				
				ReportsPlus.plugin.clearReports(cmd.toString(), player);
				

	        } else {
	            player.sendMessage(Utils.chat(config.getString("ClearCMDSyntax").replace("{prefix}", config.getString("prefix"))));
	        }
		}
		else {
			player.sendMessage(Utils.chat(config.getString("NoPermission").replace("{prefix}", config.getString("prefix"))));
		}
		return true;
		
	}
	
}