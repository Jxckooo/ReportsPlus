package me.Jacko.ReportsPlus.Commands;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import me.Jacko.ReportsPlus.ReportsPlus;
import me.Jacko.ReportsPlus.Utils.Utils;

public class ReportPlayer implements BaseCMD {
	
	FileConfiguration config = ReportsPlus.plugin.getCustomConfig();
	
	public HashMap<UUID, Long> cooldowns = new HashMap<UUID, Long>();
	
	int cooldownTime = 10;
	
	@Override
	public boolean execute(Player player, Command cmdObj, String label, String cmd, LinkedList<String> args) {
		
		Player p = player;

		
		if(args.size() > 0) {	
				
	        if(cooldowns.containsKey(p.getUniqueId())) {
	            long secondsLeft = ((cooldowns.get(p.getUniqueId())/1000)+cooldownTime) - (System.currentTimeMillis()/1000);
	            if(secondsLeft > 0) {
	                // Still cooling down
	                p.sendMessage(Utils.chat(config.getString("CooldownMessage").replaceAll("{ReportCooldown}", Long.toString(secondsLeft))));
	                return false;
	            }
	        }
	        
	        
	        cooldowns.put(p.getUniqueId(), System.currentTimeMillis());
        	
        	if(Bukkit.getServer().getPlayer(cmd.toString()) != null) {

				
				//IS ONLINE
				String[] array = args.toArray(new String[args.size()]);

			    //Displaying Array content
				StringBuilder message = new StringBuilder();
			    for (int i = 0; i < array.length; i++)
			      message.append(" ").append(array[i]); 
				
			    ReportsPlus.plugin.addReport(p, cmd.toString(), message.toString().replaceFirst(" ", ""));
			    
	            player.sendMessage(Utils.chat(config.getString("PlayerReported").replace("{ReportPlayer}", cmd.toString()).replace("{ReportReason}", message.toString().replaceFirst(" ", "")).replace("{prefix}", config.getString("prefix"))));

			}
			else {
				//NOT ONLINE
				player.sendMessage(Utils.chat(config.getString("PlayerNotOnline").replace("{prefix}", config.getString("prefix")).replace("{ReportPlayer}", cmd.toString())));
	            
			}


			

        } else {
            player.sendMessage(Utils.chat(config.getString("ReportCMDSyntax").replace("{prefix}", config.getString("prefix"))));
        }
		return true;
		
	}
	
}