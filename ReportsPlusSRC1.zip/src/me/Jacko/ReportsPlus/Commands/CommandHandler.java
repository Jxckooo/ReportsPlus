package me.Jacko.ReportsPlus.Commands;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import me.Jacko.ReportsPlus.ReportsPlus;
import me.Jacko.ReportsPlus.Utils.Utils;


public class CommandHandler implements CommandExecutor, Listener {
	
	List<String> helpStringList;
	
	FileConfiguration config = ReportsPlus.plugin.getCustomConfig();
	
	@Override
    public boolean onCommand(CommandSender sender, Command cmdObj, String label, String[] args) {
        label = label.toLowerCase();
        
        if(sender instanceof Player) {
        	
        	
        	if(ReportsPlus.connection == null) {
        		
        		sender.sendMessage(Utils.chat("&cPlease configure your SQL database with the plugin via /plugins/ReportsPlus/config.yml"));
        		return true;
        	}
        	else {
            	if(args.length == 0) {
            		
            		
            		if(sender.hasPermission(config.getString("PermissionNode"))) {
            			helpStringList = config.getStringList("Help");
                		
                		sender.sendMessage(Utils.chat(config.getString("Header").replace("{prefix}", config.getString("prefix"))));
                		
                		
                		for (int i = 0; i < config.getStringList("Help").size(); i++) {
                			sender.sendMessage(Utils.chat(helpStringList.get(i)));
                		}
                		
                		
                		sender.sendMessage(Utils.chat(config.getString("Footer")));
            		}
            		else {
            			sender.sendMessage(Utils.chat(config.getString("ReportCMDSyntax").replace("{prefix}", config.getString("prefix"))));
            		}
            		
            		
                }
                else {
                	
                	            	
                	
                	String cmd = args[0];
                	
                	
                	if(!sender.hasPermission(config.getString("PermissionNode"))) {
                		
                		if(args.length == 0) {
                			sender.sendMessage(Utils.chat(config.getString("ReportCMDSyntax").replace("{prefix}", config.getString("prefix"))));
                		}
                		else {
                			
                			LinkedList<String> list = new LinkedList<String>(Arrays.asList(args));
                			list.pollFirst();
                			
                            return new ReportPlayer().execute((Player) sender, cmdObj, label, args[0], list);
                			
                		}
                		
                	}
                	
                	
                	if(cmd.equalsIgnoreCase("player")) {
                		if(sender.hasPermission(config.getString("PermissionNode"))) {
                		
    	            		if(args.length == 1) {
    	            			sender.sendMessage(Utils.chat(config.getString("AdminReportCMDSyntax").replace("{prefix}", config.getString("prefix"))));
    	            		}
    	            		else {
    	            			
    	            			LinkedList<String> list = new LinkedList<String>(Arrays.asList(args));
    	                        list.pollFirst();
    	                        list.pollFirst();
    	                        return new ReportPlayer().execute((Player) sender, cmdObj, label, args[1], list);
    	            			
    	            			
    	            			
    	            		}
                		}
                		else {
                			sender.sendMessage(Utils.chat(config.getString("AdminReportCMDSyntax").replace("{prefix}", config.getString("prefix"))));
                		}
                	}
                	else if(cmd.equalsIgnoreCase("get")) {
                		
                		
                		if(sender.hasPermission(config.getString("PermissionNode"))) {
                			if(args.length == 1) {
                    			sender.sendMessage(Utils.chat(config.getString("GetCMDSyntax").replace("{prefix}", config.getString("prefix"))));
                    		}
                    		else {
                    			
                    			LinkedList<String> list = new LinkedList<String>(Arrays.asList(args));
                                list.pollFirst();
                                list.pollFirst();
                                return new ReportGet().execute((Player) sender, cmdObj, label, args[1], list);
                    			
                    			
                    			
                    		}
                		}
                		else {
                			sender.sendMessage(Utils.chat(config.getString("ReportCMDSyntax").replace("{prefix}", config.getString("prefix"))));
                		}
                		
                		
                	}
                	else if(cmd.equalsIgnoreCase("clear")) {
                		
                		if(sender.hasPermission(config.getString("PermissionNode"))) {
                			if(args.length == 1) {
    	            			sender.sendMessage(Utils.chat(config.getString("ClearCMDSyntax").replace("{prefix}", config.getString("prefix"))));
    	            		}
    	            		else {
    	            			
    	            			LinkedList<String> list = new LinkedList<String>(Arrays.asList(args));
    	                        list.pollFirst();
    	                        list.pollFirst();
    	                        return new ReportClear().execute((Player) sender, cmdObj, label, args[1], list);
    	            			
    	            			
    	            			
    	            		}
                		}
                		else {
                			sender.sendMessage(Utils.chat(config.getString("ReportCMDSyntax").replace("{prefix}", config.getString("prefix"))));
                		}
                		
                		
                	}
                	else if(cmd.equalsIgnoreCase("prefix")) {
                		
                		if(sender.hasPermission(config.getString("PermissionNode"))) {
    	            		if(args.length == 1) {
    	            			sender.sendMessage(Utils.chat(config.getString("PrefixCMDSyntax").replace("{prefix}", config.getString("prefix"))));
    		            	}
    		            	else {
    	            			
    	            			LinkedList<String> list = new LinkedList<String>(Arrays.asList(args));
    	                        list.pollFirst();
    	                        list.pollFirst();
    	                        return new SetPrefix().execute((Player) sender, cmdObj, label, args[1], list);
    	            			
    	            			
    	            			
    	            		}
                		}
                		else {
                			sender.sendMessage(Utils.chat(config.getString("ReportCMDSyntax").replace("{prefix}", config.getString("prefix"))));
                		}
                		
                		
                	}
                	else if(cmd.equalsIgnoreCase("reload")) {
        
                		
                		if(sender.hasPermission(config.getString("PermissionNode"))) {
                			ReportsPlus.plugin.reloadConfig();
                    		sender.sendMessage(Utils.chat(config.getString("ReloadConfig").replace("{prefix}", config.getString("prefix"))));
                		}
                		else {
                			sender.sendMessage(Utils.chat(config.getString("ReportCMDSyntax").replace("{prefix}", config.getString("prefix"))));
                		}
                		
                		
                		
                		return true;
                	}
                	else if(cmd.equalsIgnoreCase("notify")) {
                		
                		
                		if(sender.hasPermission(config.getString("PermissionNode"))) {
                			if(args.length == 2) {
                    			if(args[1].toString().toUpperCase().equalsIgnoreCase("CHAT")) {
                        			ReportsPlus.plugin.setNotify(sender, args[1].toString().toUpperCase());
                        		}
                        		else if(args[1].toString().toUpperCase().equalsIgnoreCase("TITLE")) {
                        			ReportsPlus.plugin.setNotify(sender, args[1].toString().toUpperCase());
                        		}
                        		else if(args[1].toString().toUpperCase().equalsIgnoreCase("DISCORD")) {
                        			ReportsPlus.plugin.setNotify(sender, args[1].toString().toUpperCase());
                        		}
                        		else {
                        			sender.sendMessage(Utils.chat(config.getString("InvalidArgs").replace("{prefix}", config.getString("prefix"))));
                        		}
                    		}
                    		else {
                    			sender.sendMessage(Utils.chat(config.getString("InvalidArgs").replace("{prefix}", config.getString("prefix"))));
                    			sender.sendMessage(Utils.chat(config.getString("NotificationTypes").replace("{prefix}", config.getString("prefix"))));
                    		}
                		}
                		else {
                			sender.sendMessage(Utils.chat(config.getString("ReportCMDSyntax").replace("{prefix}", config.getString("prefix"))));
                		}
                		
                		
                		
                		
                	}
                	
                	
                	
                }
        	}
        	

        } else {
            sender.sendMessage(Utils.chat("&cYou must be a player to do that!"));
        }
        
		return true;
	}

	
	
}