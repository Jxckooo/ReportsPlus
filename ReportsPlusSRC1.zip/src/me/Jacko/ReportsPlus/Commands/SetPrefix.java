package me.Jacko.ReportsPlus.Commands;

import java.util.LinkedList;

import org.bukkit.command.Command;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import me.Jacko.ReportsPlus.ReportsPlus;
import me.Jacko.ReportsPlus.Utils.Utils;

public class SetPrefix implements BaseCMD {

	FileConfiguration config = ReportsPlus.plugin.getCustomConfig();
	
	@Override
	public boolean execute(Player player, Command cmdObj, String label, String cmd, LinkedList<String> args) {
		
		
		if(player.hasPermission(config.getString("PermissionNode"))) {
			if(cmd.equalsIgnoreCase("set")) {
				
				String[] array = args.toArray(new String[args.size()]);

			    //Displaying Array content
				StringBuilder message = new StringBuilder();
			    for (int i = 0; i < array.length; i++)
			      message.append(" ").append(array[i]);
			    
			    if(message.length() > 3) {
					player.sendMessage(Utils.chat(config.getString("PrefixSet").replace("{prefix}", message.toString().replaceFirst(" ", ""))));
					
					config.set("prefix", message.toString().replaceFirst(" ", ""));
					
					ReportsPlus.plugin.saveConfig();
			    }
			    else if(message.length() < 3 || message.length() > 18) {
			    	player.sendMessage(Utils.chat(config.getString("PrefixLengthException").replace("{prefix}", config.getString("prefix"))));
			    }
				

				

	        } else {
	            player.sendMessage(Utils.chat(config.getString("PrefixCMDSyntax").replace("{prefix}", config.getString("prefix"))));
	        }
		}
		else {
			player.sendMessage(Utils.chat(config.getString("NoPermission").replace("{prefix}", config.getString("prefix"))));
		}
		return true;
		
	}

}
