package me.Jacko.ReportsPlus.Commands;

import java.util.LinkedList;

import org.bukkit.command.Command;
import org.bukkit.entity.Player;

public interface BaseCMD {

    public boolean execute(Player p, Command cmdObj, String label, String cmd, LinkedList<String> args);
    
}