package me.Jacko.ReportsPlus;


import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.IOUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import com.google.common.base.Charsets;

import me.Jacko.ReportsPlus.Commands.CommandHandler;
import me.Jacko.ReportsPlus.Extras.DiscordWebhook;
import me.Jacko.ReportsPlus.NMS.SendTitle;
import me.Jacko.ReportsPlus.NMS.v1_10_R1;
import me.Jacko.ReportsPlus.NMS.v1_11_R1;
import me.Jacko.ReportsPlus.NMS.v1_12_R1;
import me.Jacko.ReportsPlus.NMS.v1_13_R1;
import me.Jacko.ReportsPlus.NMS.v1_13_R2;
import me.Jacko.ReportsPlus.NMS.v1_14_R1;
import me.Jacko.ReportsPlus.NMS.v1_15_R1;
import me.Jacko.ReportsPlus.NMS.v1_16_R1;
import me.Jacko.ReportsPlus.NMS.v1_16_R2;
import me.Jacko.ReportsPlus.NMS.v1_16_R3;
import me.Jacko.ReportsPlus.NMS.v1_8_R1;
import me.Jacko.ReportsPlus.NMS.v1_8_R2;
import me.Jacko.ReportsPlus.NMS.v1_8_R3;
import me.Jacko.ReportsPlus.NMS.v1_9_R1;
import me.Jacko.ReportsPlus.Utils.Utils;

public class ReportsPlus extends JavaPlugin {

		
	CommandHandler commands;
	
	 
    private File customConfigFile;
    private FileConfiguration customConfig;
	
	public static java.sql.Connection connection;
	
	public List<String> wlist = new ArrayList<String>();
	
	public static ReportsPlus plugin;
	
	public static boolean debug = false;
	
	private SendTitle sendtitle;
	
	String username = "";
	String password = "";
	String url = "";
	
	@Override
	public void onEnable() {
		
		
		createCustomConfig();
		
		username = getCustomConfig().getString("db_username");
		password = getCustomConfig().getString("db_password");
		url = "jdbc:mysql://" + getCustomConfig().getString("hostname") + ":" + getCustomConfig().getString("port") + "/" + getCustomConfig().getString("db_name") + "";
		
		setUpReportsPlus();

		Logger logger = Logger.getLogger(ReportsPlus.class.getName());
		
		try { 
		    Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			logger.log(Level.WARNING, "Your server host might not support MySQL Databases or might not have the jdbc driver installed.");
		    System.err.println("jdbc driver unavailable!");
		    return;
		}
		try {
		    connection = DriverManager.getConnection(url,username,password);
		} catch (SQLException e) {
			logger.log(Level.WARNING, "You mightn't have linked your database in the configuration file!");
		}
		
		if(connection != null) {
			makeTableIfNotExist();
		}
		
		
		plugin = this;
		
		commands = new CommandHandler();
		getCommand("report").setExecutor(commands);
		
		
		logger.log(Level.INFO, "[ReportsPlus] Enabled and ready for use.");
	}
	
	
	public void onDisable() {
		
		try {
	        if (connection!=null && !connection.isClosed()) {
	            connection.close();
	        }
	    } catch(Exception e) {
	        e.printStackTrace();
	    }
		
		plugin = null;
		
	}
	
    public FileConfiguration getCustomConfig() {
        return this.customConfig;
    }
	
    private void createCustomConfig() {
        customConfigFile = new File(getDataFolder(), "config.yml");
        if (!customConfigFile.exists()) {
            customConfigFile.getParentFile().mkdirs();
            saveResource("config.yml", false);
        }

        customConfig = new YamlConfiguration();
        try {
            customConfig.load(customConfigFile);
        } catch (IOException | InvalidConfigurationException e) {
            e.printStackTrace();
        }
    }
    
	private boolean setUpReportsPlus() {

		if(getCustomConfig().getString("prefix").length() < 3) {
			getCustomConfig().set("prefix", "&cReports&a+");
		}
		else if(getCustomConfig().getString("prefix").length() > 18) {
			getCustomConfig().set("prefix", "&cReports&a+");
		}
		
        String version;

        try {

            version = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];

        } catch (ArrayIndexOutOfBoundsException whatVersionAreYouUsingException) {
            return false;
        }

        getLogger().info("Your server is running version " + version);

        if(version.equals("v1_8_R1")) {
        	sendtitle = new v1_8_R1();
        } else if (version.equals("v1_8_R2")) {
            sendtitle = new v1_8_R2();
        } else if (version.equals("v1_8_R3")) {
        	sendtitle = new v1_8_R3();
        }
        else if (version.equals("v1_9_R1")) {
        	sendtitle = new v1_9_R1();
        }
        else if (version.equals("v1_10_R1")) {
        	sendtitle = new v1_10_R1();
        }
        else if (version.equals("v1_11_R1")) {
        	sendtitle = new v1_11_R1();
        }
		else if (version.equals("v1_12_R1")) {
			sendtitle = new v1_12_R1();   	
	    }
		else if (version.equals("v1_13_R1")) {
			sendtitle = new v1_13_R1();
		}
		else if (version.equals("v1_13_R2")) {
			sendtitle = new v1_13_R2();
		}
		else if (version.equals("v1_14_R1")) {
			sendtitle = new v1_14_R1();
		}
		else if (version.equals("v1_15_R1")) {
			sendtitle = new v1_15_R1();
		}
		else if (version.equals("v1_16_R1")) {
			sendtitle = new v1_16_R1();
		}
		else if (version.equals("v1_16_R2")) {
			sendtitle = new v1_16_R2();
		}
		else if (version.equals("v1_16_R3")) {
			sendtitle = new v1_16_R3();
		}




        return sendtitle != null;
    }
	
	public String getDateTime() {
		
		Calendar cal = Calendar.getInstance();
		 
        SimpleDateFormat dateOnly = new SimpleDateFormat("MM/dd/yyyy");
        
        SimpleDateFormat timeOnly = new SimpleDateFormat("HH:mm:ss");
		
		return dateOnly.format(cal.getTime()) + " - " + timeOnly.format(cal.getTime());
				
	}
	
	public String getLocation(String playerr) {
		
		int locationx = Bukkit.getPlayer(playerr).getLocation().getBlockX();
		int locationy = Bukkit.getPlayer(playerr).getLocation().getBlockY();
		int locationz = Bukkit.getPlayer(playerr).getLocation().getBlockZ();
	
		String location;
		
		if(getCustomConfig().getString("NotificationsToggled").contains("DISCORD")) {
			location = "**X** : " + locationx + " **Y** : " + locationy + " **Z** : " + locationz;
		}
		else {
			location = "X : " + locationx + " Y : " + locationy + " Z : " + locationz;
		}
		
		
		return location;
	}
	
	String getServerVersion()
    {
        String version;
        try {

            version = Bukkit.getServer().getClass().getPackage().getName().replace(".",  ",").split(",")[3];

        } catch (ArrayIndexOutOfBoundsException whatVersionAreYouUsingException) {
            return "unknown";
        }
        return version;
    }
 	
	
	List<String> reportChatList = new ArrayList<String>();
	
	public void addReport(Player reporter, String name, String Reason) {
		
		String sql = "INSERT INTO ReportsPlus(PlayerUUID, PlayerName, ReportReason, Timestamp, Location) VALUES (?, ?, ?, ?, ?);";
		try {
			
			java.sql.PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setString(1, getUuid(name.toString()));
			stmt.setString(2, name.toString());
			stmt.setString(3, Reason.toString());
			stmt.setString(4, getDateTime());
			stmt.setString(5, getLocation(name));
			stmt.executeUpdate();
			
			for (Player online : Bukkit.getOnlinePlayers()) {
				if(online.hasPermission(getCustomConfig().getString("PermissionNode"))) {
						
					
					Logger logger = Logger.getLogger(ReportsPlus.class.getName());
					
					if(getCustomConfig().getString("NotificationsToggled").equalsIgnoreCase("TITLE")) {
						sendtitle.sendTitle(online, Reason, name);
					}
					else if(getCustomConfig().getString("NotificationsToggled").equalsIgnoreCase("CHAT")) {
						List<String> Notification;
						
						Notification = getCustomConfig().getStringList("ChatNotifcation");
						
						for (int i = 0; i < Notification.size(); i++) {
							reportChatList.add(Utils.chat(Notification.get(i).replace("{prefix}", getCustomConfig().getString("prefix")).replace("{ReportPlayer}", name.toString()).replace("{ReportReason}", Reason.toString()).replace("{ReportUUID}", getUuid(name.toString())).replace("{ReportLocation}", getLocation(name)).replace("{ReportTimestamp}", getDateTime())));
						}
						
						for(int i = 0; i < reportChatList.size(); i++) {
							online.sendMessage(reportChatList.get(i));
							
						}
						
						reportChatList.clear();
						
					}
					else if(getCustomConfig().getString("NotificationsToggled").equalsIgnoreCase("DISCORD")) {

							
						
						
						    try {					    	
								
						    	Random rand = new Random();
						    	
						    	float r = rand.nextFloat();
						    	float g = rand.nextFloat();
						    	float b = rand.nextFloat();

						    	Color randomColor = new Color(r, g, b);
						    	
						    	DiscordWebhook webhook = new DiscordWebhook(getCustomConfig().getString("WebhookURL"));
								webhook.setAvatarUrl("https://cdn3.f-cdn.com/contestentries/223663/11985279/5564289490b57_thumb900.jpg");
								webhook.setUsername(getCustomConfig().getString("WebhookName"));
								webhook.setTts(getCustomConfig().getBoolean("Text-2-Speach"));
								webhook.addEmbed(new DiscordWebhook.EmbedObject()
								        .setTitle(getCustomConfig().getString("EmbedTitle"))
								        .setColor(randomColor)
								        .addField("Name : ", name.toString(), false)
								        .addField("UUID : ", getUuid(name.toString()), false)
								        .addField("Date : ", getDateTime(), false)
								        .addField("Location : ", getLocation(name), false)
								        .addField("Reason : ", Reason.toString(), false)
								.setFooter(getCustomConfig().getString("EmbedFooter"), getCustomConfig().getString("FooterImage"))
								.setAuthor(reporter.getName(), getCustomConfig().getString("WebsiteURL"), "https://cravatar.eu/head/" + reporter.getName() + "/128.png"));
								webhook.execute();
								
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} //Handle exception
						
							
						
						
					}
					else {
						logger.log(Level.INFO, "[ReportsPlus] Unable to send report notification to admin, automatically setting Notifcations to \"TITLE\" in config.yml");
						
					}
					
				}
				
				
				
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		} 
		
		
	}
	
	
	 @Override
     public void reloadConfig() {
		 
         if (customConfigFile == null) {
        	 customConfigFile = new File(this.getDataFolder(), "config.yml");
         }
         customConfig = YamlConfiguration.loadConfiguration(customConfigFile);
         InputStream defConfigStream = this.getResource("config.yml");
         if(defConfigStream != null) {
             customConfig.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(defConfigStream, Charsets.UTF_8)));
         }
     }
	
	public void setNotify(CommandSender sender, String notify) {
		getCustomConfig().set("NotificationsToggled", notify.toString().toUpperCase());
		sender.sendMessage(Utils.chat(getCustomConfig().getString("NotificationToggledMessage").replace("{prefix}", getCustomConfig().getString("prefix")).replace("{ReportNotification}", notify.toString().toUpperCase())));
		try {
			getCustomConfig().save(customConfigFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		reloadConfig();
	}
	
	
    public String getUuid(String name) {
        String url = "https://api.mojang.com/users/profiles/minecraft/"+name;
        try {
            String UUIDJson = IOUtils.toString(new URL(url));           
            if(UUIDJson.isEmpty()) return "invalid name";                       
            JSONObject UUIDObject = (JSONObject) JSONValue.parseWithException(UUIDJson);
            return UUIDObject.get("id").toString();
        } catch (IOException | org.json.simple.parser.ParseException e) {
            e.printStackTrace();
        }
       
        return "error";
    }
	
    List<String> ReportFM;
    
	public void getReports(String name, Player sender) {
		String sql = "SELECT * FROM ReportsPlus WHERE `PlayerUUID` = ?";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, getUuid(name.toString()));
			ResultSet results = stmt.executeQuery();
			if (!results.next()) {
				sender.sendMessage(Utils.chat(getCustomConfig().getString("NoReportsShown").replace("{prefix}", getCustomConfig().getString("prefix")).replace("{ReportPlayer}", name.toString().replaceFirst(" ", ""))));
			} else {
			    
				
				
				sender.sendMessage(Utils.chat(getCustomConfig().getString("ViewingReports").replace("{prefix}", getCustomConfig().getString("prefix")).replace("{ReportPlayer}", name.toString().replaceFirst(" ", ""))));
				
				do {
            		for (int i = 0; i < getCustomConfig().getStringList("GetReportFormat").size(); i++) {
            			sender.sendMessage(Utils.chat(getCustomConfig().getStringList("GetReportFormat").get(i).replace("{ReportID}", results.getString("ReportID")).replace("{ReportPlayer}", results.getString("PlayerName")).replace("{ReportUUID}", results.getString("PlayerUUID")).replace("{ReportLocation}", results.getString("Location")).replace("{ReportTimestamp}", results.getString("Timestamp")).replace("{ReportReason}", results.getString("ReportReason"))));
            		}
				} while(results.next());
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
	
	
	public void makeTableIfNotExist() {
		
		
		
		String sql = "CREATE TABLE IF NOT EXISTS ReportsPlus(ReportID int, PlayerUUID varchar(255), PlayerName varchar(50), ReportReason varchar(255), Timestamp varchar(255), Location varchar(255));";
		
		String autoInc = "ALTER TABLE ReportsPlus\r\n" + 
				"MODIFY ReportID INT NOT NULL AUTO_INCREMENT PRIMARY KEY;";
		
		try {
			DatabaseMetaData dbm = connection.getMetaData();
			
			ResultSet tables = dbm.getTables(null, null, "ReportsPlus", null);
			
			if(tables.next()) {
				System.out.println("Skipping function table already exists.");
			}
			else {
				
				System.out.println("Creating table and columns...");
				
				java.sql.PreparedStatement stmt = connection.prepareStatement(sql);
			    stmt.executeUpdate();
			    
			    java.sql.PreparedStatement stmt1 = connection.prepareStatement(autoInc);
			    stmt1.executeUpdate();
			    
			    System.out.println("Done, ReportsPlus is ready for use!");
			}
			
		    
		    
		} catch (SQLException e) {
		    e.printStackTrace();
		}
	}
	
	public void clearReports(String name, Player p) {
		if(name.toString().equalsIgnoreCase("all")) {
			String checkReports = "SELECT * FROM ReportsPlus";
			PreparedStatement stmt;
			try {
				stmt = connection.prepareStatement(checkReports);
				ResultSet results = stmt.executeQuery();
				
				if(!results.next()) {
					p.sendMessage(Utils.chat(getCustomConfig().getString("NoGlobalReportsCleared").replace("{prefix}", getCustomConfig().getString("prefix"))));
				}
				else {
					String sql = "TRUNCATE TABLE ReportsPlus";
					
					p.sendMessage(Utils.chat(getCustomConfig().getString("ClearingGlobalReports").replace("{prefix}", getCustomConfig().getString("prefix"))));
					
					try {
					    stmt = connection.prepareStatement(sql);
					    stmt.executeUpdate();
					    p.sendMessage(Utils.chat(getCustomConfig().getString("ClearedGlobalReports").replace("{prefix}", getCustomConfig().getString("prefix"))));
					} catch (SQLException e) {
					    e.printStackTrace();
					}
				}
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		else {
			String checkReports = "SELECT * FROM ReportsPlus WHERE `PlayerUUID` = ?";
			PreparedStatement stmt;
			try {
				stmt = connection.prepareStatement(checkReports);
				stmt.setString(1, getUuid(name.toString()));
				ResultSet results = stmt.executeQuery();
				
				if(!results.next()) {
					p.sendMessage(Utils.chat(getCustomConfig().getString("NoReportsCleared").replace("{prefix}", getCustomConfig().getString("prefix")).replace("{ReportPlayer}", name.toString())));
				}
				else {
					String sql = "DELETE FROM ReportsPlus WHERE `PlayerUUID` = ?;";
					
					p.sendMessage(Utils.chat(getCustomConfig().getString("ClearingReports").replace("{prefix}", getCustomConfig().getString("prefix")).replace("{ReportPlayer}", name.toString())));
					
					try {
					    stmt = connection.prepareStatement(sql);
					    stmt.setString(1, getUuid(name.toString()));
					    stmt.executeUpdate();
					    p.sendMessage(Utils.chat(getCustomConfig().getString("ClearedReports").replace("{prefix}", getCustomConfig().getString("prefix")).replace("{ReportPlayer}", name.toString())));
					} catch (SQLException e) {
					    e.printStackTrace();
					}
				}
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
		
		
	}
  	
	
	
}