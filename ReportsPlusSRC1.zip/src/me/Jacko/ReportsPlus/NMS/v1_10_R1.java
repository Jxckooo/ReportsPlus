package me.Jacko.ReportsPlus.NMS;

import org.bukkit.ChatColor;
import org.bukkit.craftbukkit.v1_10_R1.entity.CraftPlayer;
import org.bukkit.entity.Player;

import me.Jacko.ReportsPlus.ReportsPlus;
import net.minecraft.server.v1_10_R1.IChatBaseComponent;
import net.minecraft.server.v1_10_R1.PacketPlayOutTitle;
import net.minecraft.server.v1_10_R1.IChatBaseComponent.ChatSerializer;
import net.minecraft.server.v1_10_R1.PacketPlayOutTitle.EnumTitleAction;

public class v1_10_R1 implements SendTitle {

	public void sendTitle(Player plr, String reason, String reportedPlr) {
		
		CraftPlayer name = (CraftPlayer) plr;
		
		IChatBaseComponent chatTitle = ChatSerializer.a("{\"text\": \"" + ChatColor.translateAlternateColorCodes('&', ReportsPlus.plugin.getConfig().getString("PlayerReportedTitle").replace("{ReportPlayer}", reportedPlr)) + "\"}");
		IChatBaseComponent subTitle = ChatSerializer.a("{\"text\": \"" + ChatColor.translateAlternateColorCodes('&', ReportsPlus.plugin.getConfig().getString("PlayerReasonTitle").replace("{ReportReason}", reason)) + "\"}");
		
		PacketPlayOutTitle title = new PacketPlayOutTitle(EnumTitleAction.TITLE, chatTitle);
		PacketPlayOutTitle subT = new PacketPlayOutTitle(EnumTitleAction.SUBTITLE, subTitle);
		PacketPlayOutTitle length = new PacketPlayOutTitle(5, 20, 5);

		
		
		name.getHandle().playerConnection.sendPacket(title);
		name.getHandle().playerConnection.sendPacket(subT);
		name.getHandle().playerConnection.sendPacket(length);
		
		
		
	}
	
}
