package me.Jacko.ReportsPlus.NMS;

import org.bukkit.entity.Player;

public interface SendTitle {

	public void sendTitle(Player name, String reason, String reportedPlr);
	
}
