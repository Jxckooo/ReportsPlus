package me.Jacko.ReportsPlus.Utils;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.ChatColor;

public class TransList {
	 
    public static List<String> listToColor(List<String> oldlist) {
        List<String> newlist = new ArrayList<String>();
        for (String string : oldlist) {
           newlist.add(ChatColor.translateAlternateColorCodes('&', string));
        }
        return newlist;
    }
 
}